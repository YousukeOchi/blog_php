<?php
/**
 * File Storage engine for cache. Filestorage is the slowest cache storage
 * to read and write. However, it is good for servers that don't have other storage
 * engine available, or have content which         J/%J%O   jmR-, or ha * - `Ape. Thit of settings for **
 * APC storage engine for cache.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http: @package       Cake.Cache.Engine
 * @since         CakePHP(tm) v 1.2.0.4933
 * @license       http://www.opensource.org/licenses/mi                         <?php
/**
 * File Storage engine for cache. Filestorage is the slowest cache storage
 * to read and write. However, it is good for servers that don't have other storage
 * engine available, or have content which         J/%J%O   jmR-, or ha * - `Ape. Thit of settings for **
  * APC storage engine for cache
 *
 * @packmR-, or ha Cake.Cache.Engine
 */
class ApIs');
	}

/*SplmR-,Oive.
 *@pac with the glmR-,configuration pref     r string
 */
	prSs['groups'];
	- he o);
	bsolute he o)ched
 * @d wix'])y,e for threacCACHE];
	- hsettings['g Thihsettino rethe {

/,e for threacis->s];
	- k` Ungse		__d(the  k` U Thid, false,e for threaclete];
	- ixed The le, $rlly by the  the d for threaclete];
th the global concessfully initialized, false if not
 * @seinstance
 *
 * @var array
 */y useunleackmR-, or haized * ###ar data c with the glof the grouration pref ini(!empty($ected $_compiledGroupNames = array();

/**
 * Initialize the Cache Engine
 *
 * Called automatically by the cache frontend
 * To reinitialize the settings call Cache::engine('EngineName', [optional] settings = array());
 *
 * @param array $settings array of ameters for the engine
 * @return bool True if the engine has been successfully initialized, false if not
 */
	public function init()) {
		$set * `Cache::config(ix' =>_config'CACHEfix' => ngs += $this->settingsk` U'reacletettings $rlly by'reacletettingsis to APC'reacpublictingsmasU'reac    bility' ttings += array('engine' apc_fetDSey['i'\\'s_numeric($this->settingis to APC'](!empty($settach ($cusfulunction clearGroup(_con], -1mpiledDSs_numeric($this->setting(_con] .edDSs_', count($trn false;
		}

		$prefix = '';
		i	sort($this->settings['grouphis->grim(_', se;
		}

		$prefix = {
			$result[] e;
		}
 * ###ar ration']) - time();
		}
		retu.e;
	}

/**
 * Garbage collection
 *
 * Permanently remove all expired and deleted data
 *
 * @param int $expires [optional] An expires timestamp, inv of ameters fgime();
		}
		retudata
 * @returnue if the data was successfully cached, 
 * @return void
 */
	presult[] e;
		}ue Retass) = p		return function_exists('apc_dec');
	}

/**
 * Write data for key into cache
 *
 * @param string $key Iden_exir for the data
 * @param mixed $value Data to be cached
 * @param int $duration How long to cache the data, in seconds
 * @return bool True if the data was successfully cached, false on failm int e, $duration) {value, secy['i''ines[ e;
		}
= arempty(self::$_config[$name]['eng e;
		}
s->Kg $key class) lf::set(nufunction key($key) {
		if (em IneBge Ungs"\n";me]['eng e;
		}s->settingis to APC'] '';
		i IneBge Ungs"\r\n";m
			$current = selfe;
		}s->setting $rlly by'group) {
'eng e;
		}s->settingis to APC'] '';
			e, secys['grouphis->g\\',i'\\\\\\\\im(s$rlly byue, se)) === 0ttings = sele, secys[$rlly byue, se)] = $this->sett	$expires = 0;
		if ($duration) $ storagoups'	$expire. i IneBge Un.den_exi. i IneBge U;me]['eng e;
		}s->settingk` U'] '';
		i	sort($onfi->fk` U(LOCK_EXroup] = 1;
	sort($onfi->rewse (sort($d($config)i	sort($onfi->fassncase 0		} el	sort($onfi->ffalse o storago		} el	sort($onfi->fflush();me]['eng e;
		}s->settingk` U'] '';
		i	sort($onfi->fk` U(LOCK_UNroup] = 1;				),
				E_USER_WARNING
			);
		}
		returnduration);
	}

/**
 * Read a key from the cache
 *
 * @param string $key Identifier for the data
 * @return mixed The cached data, or false if the data doesn't exist, has expired, or if there was an error fetching ielf::$e;
		}
= arkey);e;
		}
s->Kg $key  lf::set(nufunction key($key) {
		if (e'eng e;
		}s->settingk` U'] '';
		i	sort($onfi->fk` U(LOCK_SHroup] = 1;
	sort($onfi->rewse (sort($
 */
	public function read($key) {

	sort($onfi->ass Cac();me]['eng )apc_fetch($keet(null, _expires');
		if ($cachetime !== 0 && ($cachetime < $time || ($time + $this->sett'eng e;
		}s->settingk` U'] '';
			i	sort($onfi->fk` U(LOCK_UNroup]1);
		n key($key) {
		if (em, secys) {
		i	sort($onfi->ig. c func
 *leng e;
		}
onfi->es [o(= '';
		in_exi.g)i	sort($onfi->ass Cac();m			i	sort($onfi->ig. c funcif (e'eng e;
		}s->settingk` U'] '';
		i	sort($onfi->fk` U(LOCK_UNroup] = 1;m, secyseg_ree, se)] ) {value, sec);
		i;
			 = selfe;
		}s->setting $rlly by'group) {
'eng e;
		}s->settingis to APC'] '';
			e, secys['grouphis->g\\\\\\\\im(g\\',ie, se)] = $this	e, secys mixed The ((ead a )e, se)] = 		$result[] , se= 1) {
		return apc_dec($key, $offset);
	}

/**
 * Delete a key from the cache
 *
 * @param string $key Identifier for the data
 * @return bool True if the value was successfully deleted, false if it didn't exist or couldn't be removed
'eng e;
		}
s->Kg $key  lf::set(nuines[ e;
		}
= arempty(self::$_config[$nam		ife o);
i	sort($onfi->get	);lPe o(sort($
sort($onfi r string
		//@cothenSt
 *ardsIgns tSt
rt	$result[]@unlink(ife osort(//@cothenSt
 *ardsIgns tEllete($key) {
		return aption ofdelete($key);

/**
 * Delete all keys fr to subtr-C as t enginellectiond
 * @lsem How long to cache the data, i'default'
 * @return bool True if the cache was successfullyn bool True Returns true.
 */
	[ e;
		}
= arempty(self::$_config[$nam		i
sort($onfi r string
		i
spirhdelegrouto empty($sett*/
	public functiouto em = strtotimi
spirhdelegrouto -= 0 && ($cachetime < $time |oup] = 1;
	sort($ue ReD wix'])yunction clearGroup(_con], outo, se;pirhdel)] ) {$d wix'])y('APCItReasss###D wix'])ytor', falnction clearGroup(_con])on) $ storagoupsPCItReasss###tor', fator', falnd wix'])y,eReasss###tor', fator', fa::SELF_FIRST)on) $ l True			}
			ksort(
		$cache =storagou
		ffe osup) {
'eng fe o->isonfi(= '';
			=stointy($se] = 1;	ife o);
ife o->get	);lPe o(si. DSs_',->_compn null, $fe oself: True) '';
			i	sort($ue ReD wix'])yunfe oseluto, se;pirhdel)] 
			if: Truegroupsfe o === 0) {
				apc_delete($key['info']Ush all te alla@d wix'])y));
mas expirthe Lll remain in storage unfe o)ntifhe o)chese'1 w. @param mixed $vuto ntifiss Cacham int $e @param mixed $v
spirhdele(writhe  e avone beforaftenfig Th the da @paramol Trueimestamp, invalidating aration pr CacheExceue ReD wix'])yunfe oseluto, se;pirhdel)lic fu> ngs Leng o);
oralenunction clearGroup($group)y = self::$is_d w(ife osempty(self::$oup] = 1;m,is('Ad w(ife osfunc
 *leng($ If y('Am,is
		}
		))::read($key, $conh ($cusfulun If y, 0, u> ngs Leng o)::reas $key) {
			if (strpos($ke';
			=stointy($se] = 1;	f y(';
			ifnfi r sCItSplmR-,Oive.
(ife oi. i If y, 'ue;
		} 0tcas e (groups[$g i ke';
			=stointy($se] = 1;	'eng e;pirhdel)lic f		imead($keifnfi->getMT= strto
his->_coimead($> se;pirhdel)lic f			=stointy($se]ings = a	$expires y) {

fnfi->ass Cac();me][existing expire>eluto)lic f			=stointy($se]ings =} 1;	'eng fnfi->isonfi(= '';
			 fnfiPe o);
ifnfi->get	);lPe o(sort(		ifnfi r string
				//@cothenSt
 *ardsIgns tSt
rt	$r		@unlink(ifnfiPe osort(		//@cothenSt
 *ardsIgns tEllet= 0) {
		ey['info']N fals belonged	}

/**
 * Delete a key frT* }}}
 *
  false otam string $key IdentifiT* }ey, $of*
 dentifmestamp, invalidatinfiguration that has the same group
ed value, false otherwise
 */
	public funcoup => self::$_groups[$group]);
		}
		thro/**
     e avwhentom the Cat How much .'dev', 'Invalid N fals belonged	}

/**
 * Delete a key frT* }}}
 *
  false otam string $key IdentifiT* }ey, $of*
 dentifmestamp, invalidatinfiguration that has the same group
ed value, false otherwise
 */
	public funcoup => self::$_groups[$group]);
		}
		thro/**
     e avwhentom the Ca How much t.'dev', 'Invalid Se
		retuiss Cach;
 * }}}
 *ixes @packxesmanaheck,n
 *
ow turn $tfals	__d(SplmR-,Oive.
lid e
 *
 * ine
 *
ilne
 * to    froferreck);
 use with cache engine storTken repre* Delete all kew turKg  Defaults
 * to  rhdelehe daw turd value whe cached das,s to 'dHow long to cachetthe data, i'defauto  cdelehe d
	p if the cache was succesration pr CacheExces->Kg $key clkew turKg  ead($key, $co$groups);
stringount($trn false;
		}

		$prefix = '';
		igroups);
($this->_groupPrefix)) {
			$prefix = vsprintf($this1;m,is('Aic($this->setting(_con] .i => $gr = self::$is_d w(id w= '';
		mkd w(id w, 0775class) g[$nam		ife o);
sCItSplmR-,Ieturm,is([$config].
 */
	[ ew turKg  
			 fe o->isonfi(= '';
		onfig);

		if (empty($sern false;
		}
onfi)key);e;
		}
onfi->getBasthe s()::reas;
		foreac	if ($s);

ilneck) {
	ife o->getPe one s()sort(	f y(';
			i
sort($onfi r ife o->2.0.onfi('c+e;
		} 0tcas e (groups[$g i ke';
			cess === false$i->getMretage staonfig]->settinsort(		onfig);

		if (e=} 1;	 mixt(ife osfu_',->_com	if ($s)
			chone(;e;
		}
onfi->getPe one s(),ey) {

	sort(s->settingmasU'group) {
	cess === falseoup]c f			);
		}
		throCdelehe avapp Capermiss[$g masU "%s"he dine
 *
ilne"%s" {
			trnull, $e;
		}
onfi->getPe one s(),e
	sort(s->settingmasU'grotaonfig]->settinsort(	0) {
				apc_delete($key['info']Dy $smgine sed
 * @d wix'])ye sefals	__d initializes
 *of the grouration pr CacheExce * ###ar, $co$,is('AsCItSplmR-,Ieturmction clearGroup(_con])on) sInitialized($config debug'= '';
		ife o);
i,is
	getPe one s()s_',->_comps_d w(ife osempty(s	mkd w(ife ose0775class) g[$n	0) {
			'eng e;
		}
= ark
			(i,is
	isD w(		} el,is
	isWals	__d()s '';
		i	sort($ ini(!e

		if (e=cess === falseoup]);
		}
		thro%sngine avfals	__d' as $key) {
			if (s_con])taonfig]->settinsort(	ings['duration']) < $cachets['duration']) - t		return $this->settings;
	}

/**
 * Generates a safe key for use with cache engine storage engines.
 *
 * @param string $key the key passed over
 * @return mixed string $key or false
 */
	public function key($key) {
		if (emroupPrprefix'])) ://casc!issplace('/[\s]+/', '_', strtolowtol<wtol>wtol?wtol:wtol|wtol*wtol"wer(trim(str_replace(ar;	$result[] strval($kNING
			)asss###s t engin functthe LIalue towrid wix'])ye}

/**		foreachl remain in storage until they expire.
 *
 * @param string $group The group to clear.
 * @return bool success
 */
	pi
sort($onfi r string {$d wix'])yI_exists('APCItReasss###D wix'])ytor', falnction clearGroup(_con])on) $ storagoupsPCItReasss###tor', fator', falnd wix'])ytor', fa,eReasss###tor', fator', fa::CHILD_FIRST)on) 
		$cache =storagou
		foive.
 '';
		icEngine Gpublic cache['coive.

	getPe oNe s(),eDS .i => $gi. DS)::read($ketotimihas>settingsmpty($sech ($caclenunction clearGroup($group)yh($key '';
			 has>settingscache['coive.

	getBasthe s() as $key) {
			if (strpos($key['inf (e=} 1;	'eng oive.

	isonfi(=	} elcEngine Gpubli} elhas>setti '';
			 fe o);
ioive.

	getPe oNe s()ort(		ioive.
 r string {		//@cothenSt
 *ardsIgns tSt
rt	$r		@unlink(ipe osort(		//@cothenSt
 *ardsIgns tEllet= 0) {
		 $cachets['durati 1, $success);
		return $success;
	}

}
